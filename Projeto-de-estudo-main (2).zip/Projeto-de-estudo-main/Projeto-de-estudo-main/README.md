# Projeto-de-estudo
Testando js integrado com html usando o tailwind
